function myFunction(){
    alert("'Clouds'- by Neil Chand");
}

function myFunction1(){
    alert("'Sunset'- by Dave Watt");
}

function myFunction2(){
    alert("'Beach'- by Nora Hailey");
}

function myFunction3(){
    alert("'Island'- by Sneha Duggal");
}

